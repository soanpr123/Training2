class SignUpBloc {

}