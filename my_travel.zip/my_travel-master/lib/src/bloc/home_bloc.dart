class HomeBloc{
}
final homeBloc = HomeBloc();