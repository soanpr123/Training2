class ErrorMessage{
	String status, message;
	
	ErrorMessage({this.status, this.message});
}