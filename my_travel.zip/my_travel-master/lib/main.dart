import 'package:flutter/material.dart';
import 'package:my_travel/src/app.dart';

void main() {
  runApp(new MaterialApp(
    home: new MyApp(),
    debugShowCheckedModeBanner: false,
  ));
}
